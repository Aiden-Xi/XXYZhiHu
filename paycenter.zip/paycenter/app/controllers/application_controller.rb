class ApplicationController < ActionController::Base
  # Prevent CSRF attacks by raising an exception.
  # For APIs, you may want to use :null_session instead.
  #protect_from_forgery with: :exception

  # before_filter :configure_permitted_parameters, if: :devise_controller?

  # 验证客户
  before_filter :authenticate_customer!

  before_filter :custom_setting, unless: :devise_controller?

  def custom_setting
    if params[:customer].present?
      params[:customer_model] = current_customer
    else
      params[:customer] = current_customer
    end
  end

end
