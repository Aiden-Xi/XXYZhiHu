class AppsController < ApplicationController

  # 创建app
  def create
    @response, @app = App.create_with_options(params)
    if @response.code == Response::Code::SUCCESS
      redirect_to apps_path, flash: {notice: '添加成功'}
    else
      redirect_to apps_path, flash: {notice: @response.message}
    end
  end

  def show
    @app = App.query_first_by_options(id: params[:id], customer_id: params[:customer].id)
  end

  # 查看所有app
  def index
    @apps = current_customer.apps
  end

  # 更新或创建支付宝渠道
  def upsert_alipay
    @response, @alipay_channel, @app = AlipayChannel.upsert_with_options(params)

    notice = '保存成功'
    notice = @response.message if @response.code != Response::Code::SUCCESS

    redirect_to app_path, flash: {notice: notice}
  end

  # 更新或创建微信渠道
  def upsert_wx
    @response, @wx_channel, @app = WxChannel.upsert_with_options(params)

    notice = '保存成功'
    notice = @response.message if @response.code != Response::Code::SUCCESS

    redirect_to app_path, flash: {notice: notice}
  end
end
