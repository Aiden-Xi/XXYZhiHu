class CustomersController < ApplicationController
  # skip_before_action :authentication_token_before_filter

  def show
  end

  def update
    @response, @customer = Customer.update_with_options(params)
    if @response.code == Response::Code::SUCCESS
      notice = '更新成功'
    else
      notice = @response.message
    end
    redirect_to customer_path(params[:customer_model]), flash: {notice: notice}
  end
end
