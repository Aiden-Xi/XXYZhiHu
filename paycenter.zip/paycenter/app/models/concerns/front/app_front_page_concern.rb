# encoding: utf-8

module Concerns::Front::AppFrontPageConcern

  extend ActiveSupport::Concern

  module ClassMethods

    # 后台管理添加app
    #
    # @param options [Hash]
    # @option options [Customer] :customer 客户
    # @option options [APP] :app APP数据
    #
    # @return [Array] response, app
    #
    def create_with_options(options = {})
      app = nil
      response = Response.__rescue__ do |res|
        app_json, customer = options[:app], options[:customer]

        res.__raise__miss_request_params('参数缺失') if app_json.blank? || app_json[:name].blank? || customer.blank?

        app = App.new
        app.name = app_json[:name]
        app.code = rand(36 ** 6).to_s(36)
        app.customer = customer
        app.save!
      end

      return response, app
    end

  end
end
