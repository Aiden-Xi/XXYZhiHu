module WxPay
  VERSION = "0.4.1"
end
