Rails.application.routes.draw do
  devise_for :customers, controllers: {sessions: 'customer/sessions', registrations: 'customer/registrations'}
  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".
  #
  resources :customers do
    collection do
      get :setting
    end
  end

  resources :apps do
    member do
      post :upsert_alipay
      post :upsert_wx
    end
  end

  namespace :api do
    namespace :v1 do
      resources :charges do
        post :wx_notify
        post :alipay_notify
      end
    end
  end

  # You can have the root of your site routed with "root"
  root 'apps#index'
end
