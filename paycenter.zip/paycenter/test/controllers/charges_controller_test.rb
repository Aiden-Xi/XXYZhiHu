require 'test_helper'

class ChargesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
