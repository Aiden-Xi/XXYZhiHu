# == Schema Information
#
# Table name: alipay_channels
#
#  id                :integer          not null, primary key
#  pid               :string(255)                            # PID
#  alipay_account    :string(255)                            # 支付宝账号
#  alipay_verify_key :string(255)                            # 支付宝安全校验码（Key）
#  public_key        :text(65535)                            # 支付宝公钥
#  rsa_key           :text(65535)                            # 商户RSA私钥
#  customer_id       :integer                                # 所属客户
#  created_at        :datetime         not null
#  updated_at        :datetime         not null
#  app_id            :integer                                # 关联应用
#

require 'test_helper'

class AlipayChannelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
