# == Schema Information
#
# Table name: charges
#
#  id             :integer          not null, primary key
#  live_mode      :boolean          not null              # 沙盒模式
#  paid           :boolean          not null              # 已经支付
#  refunded       :boolean          not null              # 已经退款
#  app_id         :integer                                # 关联的应用
#  channel        :string(255)      not null              # 支付渠道
#  order_no       :string(255)                            # 客户订单号
#  amount         :integer                                # 订单金额
#  subject        :string(255)                            # 交易主题
#  body           :string(255)                            # 交易介绍
#  time_paid      :datetime                               # 支付时间
#  time_expired   :datetime                               # 失效时间
#  transaction_no :string(255)                            # 支付平台交易号
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#  credential     :text(65535)                            # 支付渠道凭据
#  deleted_at     :datetime                               # 删除时间
#  batch_no       :string(255)                            # 支付宝用: 退款号
#

require 'test_helper'

class ChargeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
