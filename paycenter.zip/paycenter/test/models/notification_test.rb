# == Schema Information
#
# Table name: notifications
#
#  id                    :integer          not null, primary key
#  channel               :string(255)                            # 支付渠道
#  charge_id             :integer                                # 关联支付
#  received              :boolean                                # 客服服务器已接收到通知
#  send_time             :integer                                # 当前向客户服务器发送通知次数
#  original_notification :text(65535)                            # 微信服务器发来的原始通知内容
#  created_at            :datetime         not null
#  updated_at            :datetime         not null
#

require 'test_helper'

class NotificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
