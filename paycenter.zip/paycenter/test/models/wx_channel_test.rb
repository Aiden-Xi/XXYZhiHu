# == Schema Information
#
# Table name: wx_channels
#
#  id                        :integer          not null, primary key
#  wx_app_id                 :string(255)                            # 微信App id
#  wx_app_secret             :string(255)                            # 微信App Secret
#  parter_id                 :string(255)                            # 商户id
#  pay_secret                :text(65535)                            # 商户支付密钥
#  refund_operator           :string(255)                            # 商户添加的退款操作员 ID
#  client_certificate        :text(65535)                            # 微信客户端证书
#  client_certificate_secret :text(65535)                            # 微信客户端证书密钥
#  customer_id               :integer                                # 所属客户
#  created_at                :datetime         not null
#  updated_at                :datetime         not null
#  app_id                    :integer                                # 关联应用
#

require 'test_helper'

class WxChannelTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
